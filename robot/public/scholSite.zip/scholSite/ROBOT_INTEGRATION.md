 # راهنمای هماهنگی با ربات بله

## 🔗 اتصال ربات بله به وب‌سایت

### مراحل هماهنگ‌سازی

#### 1. تنظیم API Endpoints در ربات

در فایل `main.py` ربات، این کدها را اضافه کنید:

```python
import requests
import json

# تنظیمات اتصال به وب‌سایت
WEBSITE_URL = "http://localhost:5000"  # آدرس وب‌سایت

def sync_user_to_website(user_data):
    """هماهنگ‌سازی کاربر با وب‌سایت"""
    try:
        response = requests.post(f"{WEBSITE_URL}/api/sync_robot_data", 
                               json={
                                   "type": "registration",
                                   "user_data": user_data
                               })
        return response.json()
    except Exception as e:
        print(f"خطا در هماهنگ‌سازی: {e}")
        return None

def get_user_from_website(national_id):
    """دریافت اطلاعات کاربر از وب‌سایت"""
    try:
        response = requests.get(f"{WEBSITE_URL}/api/get_user_by_national_id/{national_id}")
        return response.json()
    except Exception as e:
        print(f"خطا در دریافت اطلاعات: {e}")
        return None
```

#### 2. تغییر در registration_module.py

در فایل `registration_module.py` ربات، این تغییرات را اعمال کنید:

```python
def _handle_complete_registration(self, chat_id, user_id):
    """تکمیل ثبت‌نام و هماهنگ‌سازی با وب‌سایت"""
    user_data = self.user_data.get(str(user_id), {})
    
    if user_data:
        # هماهنگ‌سازی با وب‌سایت
        website_user = {
            "national_id": user_data.get("national_id"),
            "full_name": user_data.get("full_name"),
            "phone": user_data.get("phone"),
            "user_type": user_data.get("user_type", "quran_student"),
            "role": "student",
            "registration_date": datetime.now().isoformat(),
            "is_active": True
        }
        
        result = sync_user_to_website(website_user)
        
        if result and result.get("success"):
            self.send_message(chat_id, "✅ ثبت‌نام شما با موفقیت در وب‌سایت هماهنگ شد!")
        else:
            self.send_message(chat_id, "⚠️ ثبت‌نام در ربات انجام شد اما هماهنگ‌سازی با وب‌سایت با مشکل مواجه شد.")
    
    # ادامه کد موجود...
```

#### 3. تغییر در login process

برای ورود کاربران از وب‌سایت به ربات:

```python
def check_website_user(self, national_id):
    """بررسی وجود کاربر در وب‌سایت"""
    user_data = get_user_from_website(national_id)
    if user_data and not user_data.get("error"):
        return user_data
    return None

def handle_website_login(self, message):
    """ورود کاربران وب‌سایت به ربات"""
    national_id = message.get("text", "")
    
    # بررسی در وب‌سایت
    website_user = self.check_website_user(national_id)
    
    if website_user:
        # کاربر در وب‌سایت وجود دارد
        user_id = message["from"]["id"]
        self.user_data[str(user_id)] = website_user
        self.save_data(self.user_data)
        
        self.send_message(message["chat"]["id"], 
                         f"✅ خوش آمدید {website_user['full_name']}!\n"
                         "شما از طریق وب‌سایت ثبت‌نام کرده‌اید.")
    else:
        # کاربر در وب‌سایت وجود ندارد
        self.send_message(message["chat"]["id"], 
                         "❌ کاربری با این کد ملی در وب‌سایت یافت نشد.\n"
                         "لطفاً ابتدا در وب‌سایت ثبت‌نام کنید.")
```

### 4. تغییر در main.py ربات

در فایل `main.py` ربات، این تغییرات را اعمال کنید:

```python
def process_update(self, update):
    """پردازش هر آپدیت"""
    try:
        if "message" in update:
            message = update["message"]
            text = message.get("text", "")
            
            # بررسی ورود از وب‌سایت
            if text.startswith("/website_login"):
                national_id = text.replace("/website_login ", "")
                self.registration_module.handle_website_login(message)
                return
            
            # ادامه کد موجود...
```

### 5. دستورات جدید ربات

#### دستور `/website_login`
برای ورود کاربران وب‌سایت به ربات:
```
/website_login 1234567890
```

#### دستور `/sync_status`
برای بررسی وضعیت هماهنگ‌سازی:
```
/sync_status
```

### 6. تنظیمات امنیتی

#### API Key (اختیاری)
برای امنیت بیشتر، می‌توانید API Key اضافه کنید:

```python
# در وب‌سایت
API_KEY = "your-secret-api-key"

@app.route('/api/sync_robot_data', methods=['POST'])
def sync_robot_data():
    if request.headers.get('X-API-Key') != API_KEY:
        return jsonify({'error': 'Unauthorized'}), 401
    
    # ادامه کد...

# در ربات
def sync_user_to_website(user_data):
    headers = {'X-API-Key': 'your-secret-api-key'}
    response = requests.post(f"{WEBSITE_URL}/api/sync_robot_data", 
                           json={"type": "registration", "user_data": user_data},
                           headers=headers)
    return response.json()
```

### 7. تست هماهنگ‌سازی

#### مرحله 1: ثبت‌نام در ربات
1. کاربر در ربات ثبت‌نام می‌کند
2. ربات داده‌ها را به وب‌سایت ارسال می‌کند
3. کاربر می‌تواند در وب‌سایت وارد شود

#### مرحله 2: ثبت‌نام در وب‌سایت
1. کاربر در وب‌سایت ثبت‌نام می‌کند
2. کاربر می‌تواند با دستور `/website_login` در ربات وارد شود

#### مرحله 3: بررسی وضعیت
- بررسی فایل‌های JSON در هر دو طرف
- تست API endpoints
- بررسی پیام‌های خطا

### 8. مدیریت خطاها

#### خطاهای رایج
1. **اتصال ناموفق**: بررسی آدرس وب‌سایت
2. **خطای 404**: بررسی endpoint ها
3. **خطای 500**: بررسی کدهای سرور

#### لاگ‌گیری
```python
import logging

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

def sync_user_to_website(user_data):
    try:
        logger.info(f"هماهنگ‌سازی کاربر: {user_data.get('national_id')}")
        # کد هماهنگ‌سازی
        logger.info("هماهنگ‌سازی موفق")
    except Exception as e:
        logger.error(f"خطا در هماهنگ‌سازی: {e}")
```

### 9. بهینه‌سازی

#### کش کردن
```python
import time

user_cache = {}
CACHE_DURATION = 300  # 5 دقیقه

def get_user_from_website(national_id):
    # بررسی کش
    if national_id in user_cache:
        cache_time, user_data = user_cache[national_id]
        if time.time() - cache_time < CACHE_DURATION:
            return user_data
    
    # دریافت از وب‌سایت
    user_data = requests.get(f"{WEBSITE_URL}/api/get_user_by_national_id/{national_id}").json()
    
    # ذخیره در کش
    user_cache[national_id] = (time.time(), user_data)
    return user_data
```

### 10. مستندات API

#### Endpoints موجود

**POST /api/sync_robot_data**
- هماهنگ‌سازی داده‌های ربات با وب‌سایت
- Body: `{"type": "registration", "user_data": {...}}`

**GET /api/get_user_by_national_id/<national_id>**
- دریافت اطلاعات کاربر بر اساس کد ملی
- Response: اطلاعات کاربر یا `{"error": "کاربر یافت نشد"}`

### 11. نکات مهم

1. **همگام‌سازی**: همیشه داده‌ها را در هر دو طرف به‌روزرسانی کنید
2. **اعتبارسنجی**: داده‌های ورودی را اعتبارسنجی کنید
3. **خطاها**: خطاها را مدیریت و لاگ کنید
4. **امنیت**: از HTTPS و API Key استفاده کنید
5. **تست**: قبل از استفاده در تولید، تست کنید

### 12. مثال کامل

```python
# در ربات
def complete_registration_with_website(user_id):
    user_data = self.user_data.get(str(user_id), {})
    
    if user_data:
        # آماده‌سازی داده‌ها
        website_data = {
            "national_id": user_data["national_id"],
            "full_name": user_data["full_name"],
            "phone": user_data["phone"],
            "user_type": user_data.get("user_type", "quran_student"),
            "role": "student",
            "registration_date": datetime.now().isoformat(),
            "is_active": True
        }
        
        # ارسال به وب‌سایت
        try:
            response = requests.post(
                f"{WEBSITE_URL}/api/sync_robot_data",
                json={"type": "registration", "user_data": website_data},
                timeout=10
            )
            
            if response.status_code == 200:
                result = response.json()
                if result.get("success"):
                    return True, "هماهنگ‌سازی موفق"
                else:
                    return False, "خطا در هماهنگ‌سازی"
            else:
                return False, f"خطای HTTP: {response.status_code}"
                
        except requests.exceptions.RequestException as e:
            return False, f"خطای اتصال: {e}"
    
    return False, "داده‌های کاربر یافت نشد"
```

این راهنما به شما کمک می‌کند تا ربات بله و وب‌سایت را به درستی هماهنگ کنید.