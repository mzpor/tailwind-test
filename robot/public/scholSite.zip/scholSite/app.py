from flask import Flask, render_template, request, jsonify, redirect, url_for, session, flash
import json
import os
from datetime import datetime
import hashlib
import uuid

app = Flask(__name__)
app.secret_key = 'your-secret-key-here'

# تنظیمات اولیه
UPLOAD_FOLDER = 'uploads'
if not os.path.exists(UPLOAD_FOLDER):
    os.makedirs(UPLOAD_FOLDER)

# فایل‌های JSON
USERS_FILE = 'users.json'
CLASSES_FILE = 'classes.json'
REPORT_CARDS_FILE = 'report_cards.json'
SETTINGS_FILE = 'settings.json'

def load_json_data(filename):
    """بارگذاری داده‌های JSON"""
    if os.path.exists(filename):
        with open(filename, 'r', encoding='utf-8') as f:
            return json.load(f)
    return {}

def save_json_data(filename, data):
    """ذخیره داده‌های JSON"""
    with open(filename, 'w', encoding='utf-8') as f:
        json.dump(data, f, ensure_ascii=False, indent=2)

def hash_password(password):
    """هش کردن پسورد"""
    return hashlib.sha256(password.encode()).hexdigest()

def is_admin(user_id):
    """بررسی اینکه آیا کاربر مدیر است"""
    users = load_json_data(USERS_FILE)
    user = users.get(str(user_id), {})
    return user.get('role') == 'admin'

def is_teacher(user_id):
    """بررسی اینکه آیا کاربر مربی است"""
    users = load_json_data(USERS_FILE)
    user = users.get(str(user_id), {})
    return user.get('role') in ['teacher', 'admin']

# Routes
@app.route('/')
def index():
    """صفحه اصلی"""
    return render_template('1index.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    """صفحه ورود"""
    if request.method == 'POST':
        national_id = request.form.get('national_id')
        password = request.form.get('password')
        
        users = load_json_data(USERS_FILE)
        
        # جستجو بر اساس کد ملی
        user_id = None
        for uid, user_data in users.items():
            if user_data.get('national_id') == national_id:
                user_id = uid
                break
        
        if user_id and users[user_id]['password'] == hash_password(password):
            session['user_id'] = user_id
            session['user_name'] = users[user_id]['full_name']
            session['user_role'] = users[user_id].get('role', 'student')
            flash('ورود موفقیت‌آمیز بود!', 'success')
            return redirect(url_for('dashboard'))
        else:
            flash('کد ملی یا رمز عبور اشتباه است!', 'error')
    
    return render_template('2login.html')

@app.route('/register', methods=['GET', 'POST'])
def register():
    """صفحه ثبت‌نام"""
    if request.method == 'POST':
        national_id = request.form.get('national_id')
        full_name = request.form.get('full_name')
        phone = request.form.get('phone')
        password = request.form.get('password')
        user_type = request.form.get('user_type', 'quran_student')
        
        users = load_json_data(USERS_FILE)
        
        # بررسی تکراری نبودن کد ملی
        for user_data in users.values():
            if user_data.get('national_id') == national_id:
                flash('این کد ملی قبلاً ثبت شده است!', 'error')
                return render_template('3register.html')
        
        # ایجاد کاربر جدید
        new_user_id = str(uuid.uuid4())
        users[new_user_id] = {
            'national_id': national_id,
            'full_name': full_name,
            'phone': phone,
            'password': hash_password(password),
            'user_type': user_type,
            'role': 'student',
            'registration_date': datetime.now().isoformat(),
            'is_active': True
        }
        
        save_json_data(USERS_FILE, users)
        flash('ثبت‌نام با موفقیت انجام شد! حالا می‌توانید وارد شوید.', 'success')
        return redirect(url_for('login'))
    
    return render_template('3register.html')

@app.route('/dashboard')
def dashboard():
    """داشبورد کاربر"""
    if 'user_id' not in session:
        return redirect(url_for('login'))
    
    user_id = session['user_id']
    users = load_json_data(USERS_FILE)
    user_data = users.get(user_id, {})
    
    # دریافت آمار
    total_students = len([u for u in users.values() if u.get('user_type') == 'quran_student'])
    total_teachers = len([u for u in users.values() if u.get('role') in ['teacher', 'admin']])
    
    return render_template('4dashboard.html', 
                         user=user_data, 
                         total_students=total_students,
                         total_teachers=total_teachers)

@app.route('/report-card')
def report_card():
    """صفحه کارنامه"""
    if 'user_id' not in session:
        return redirect(url_for('login'))
    
    user_id = session['user_id']
    report_cards = load_json_data(REPORT_CARDS_FILE)
    user_reports = report_cards.get(user_id, [])
    
    return render_template('5report-card.html', reports=user_reports)

@app.route('/classes')
def classes():
    """صفحه کلاس‌های کارگاهی"""
    if 'user_id' not in session:
        return redirect(url_for('login'))
    
    classes_data = load_json_data(CLASSES_FILE)
    return render_template('6classes.html', classes=classes_data)

@app.route('/admin')
def admin_panel():
    """پنل مدیر"""
    if 'user_id' not in session or not is_admin(session['user_id']):
        flash('دسترسی غیرمجاز!', 'error')
        return redirect(url_for('dashboard'))
    
    users = load_json_data(USERS_FILE)
    classes_data = load_json_data(CLASSES_FILE)
    settings = load_json_data(SETTINGS_FILE)
    
    return render_template('admin_panel.html', 
                         users=users, 
                         classes=classes_data,
                         settings=settings)

@app.route('/admin/users')
def admin_users():
    """مدیریت کاربران"""
    if 'user_id' not in session or not is_admin(session['user_id']):
        return jsonify({'error': 'دسترسی غیرمجاز'}), 403
    
    users = load_json_data(USERS_FILE)
    return jsonify(users)

@app.route('/admin/add_user', methods=['POST'])
def admin_add_user():
    """افزودن کاربر جدید"""
    if 'user_id' not in session or not is_admin(session['user_id']):
        return jsonify({'error': 'دسترسی غیرمجاز'}), 403
    
    data = request.json
    users = load_json_data(USERS_FILE)
    
    new_user_id = str(uuid.uuid4())
    users[new_user_id] = {
        'national_id': data['national_id'],
        'full_name': data['full_name'],
        'phone': data['phone'],
        'password': hash_password(data['password']),
        'user_type': data['user_type'],
        'role': data['role'],
        'registration_date': datetime.now().isoformat(),
        'is_active': True
    }
    
    save_json_data(USERS_FILE, users)
    return jsonify({'success': True, 'user_id': new_user_id})

@app.route('/admin/update_user/<user_id>', methods=['PUT'])
def admin_update_user(user_id):
    """ویرایش کاربر"""
    if 'user_id' not in session or not is_admin(session['user_id']):
        return jsonify({'error': 'دسترسی غیرمجاز'}), 403
    
    data = request.json
    users = load_json_data(USERS_FILE)
    
    if user_id in users:
        users[user_id].update(data)
        if 'password' in data:
            users[user_id]['password'] = hash_password(data['password'])
        save_json_data(USERS_FILE, users)
        return jsonify({'success': True})
    
    return jsonify({'error': 'کاربر یافت نشد'}), 404

@app.route('/admin/delete_user/<user_id>', methods=['DELETE'])
def admin_delete_user(user_id):
    """حذف کاربر"""
    if 'user_id' not in session or not is_admin(session['user_id']):
        return jsonify({'error': 'دسترسی غیرمجاز'}), 403
    
    users = load_json_data(USERS_FILE)
    
    if user_id in users:
        del users[user_id]
        save_json_data(USERS_FILE, users)
        return jsonify({'success': True})
    
    return jsonify({'error': 'کاربر یافت نشد'}), 404

@app.route('/admin/classes', methods=['GET', 'POST'])
def admin_classes():
    """مدیریت کلاس‌ها"""
    if 'user_id' not in session or not is_admin(session['user_id']):
        return jsonify({'error': 'دسترسی غیرمجاز'}), 403
    
    if request.method == 'POST':
        data = request.json
        classes_data = load_json_data(CLASSES_FILE)
        
        new_class_id = str(uuid.uuid4())
        classes_data[new_class_id] = {
            'name': data['name'],
            'instructor': data['instructor'],
            'description': data['description'],
            'price': data['price'],
            'duration': data['duration'],
            'capacity': data['capacity'],
            'is_active': True,
            'created_at': datetime.now().isoformat()
        }
        
        save_json_data(CLASSES_FILE, classes_data)
        return jsonify({'success': True, 'class_id': new_class_id})
    
    classes_data = load_json_data(CLASSES_FILE)
    return jsonify(classes_data)

@app.route('/logout')
def logout():
    """خروج از سیستم"""
    session.clear()
    flash('شما با موفقیت خارج شدید.', 'success')
    return redirect(url_for('index'))

# API برای هماهنگی با ربات
@app.route('/api/sync_robot_data', methods=['POST'])
def sync_robot_data():
    """هماهنگ‌سازی داده‌های ربات با سایت"""
    data = request.json
    
    if data.get('type') == 'registration':
        # هماهنگ‌سازی ثبت‌نام از ربات
        users = load_json_data(USERS_FILE)
        robot_user = data['user_data']
        
        # بررسی وجود کاربر
        existing_user = None
        for uid, user_data in users.items():
            if user_data.get('national_id') == robot_user['national_id']:
                existing_user = uid
                break
        
        if existing_user:
            # به‌روزرسانی اطلاعات
            users[existing_user].update(robot_user)
        else:
            # ایجاد کاربر جدید
            new_user_id = str(uuid.uuid4())
            users[new_user_id] = robot_user
        
        save_json_data(USERS_FILE, users)
        return jsonify({'success': True, 'message': 'داده‌ها هماهنگ شدند'})
    
    return jsonify({'error': 'نوع داده نامعتبر'}), 400

@app.route('/api/get_user_by_national_id/<national_id>')
def get_user_by_national_id(national_id):
    """دریافت اطلاعات کاربر بر اساس کد ملی"""
    users = load_json_data(USERS_FILE)
    
    for user_data in users.values():
        if user_data.get('national_id') == national_id:
            return jsonify(user_data)
    
    return jsonify({'error': 'کاربر یافت نشد'}), 404

if __name__ == '__main__':
    # ایجاد فایل‌های JSON اولیه
    if not os.path.exists(USERS_FILE):
        save_json_data(USERS_FILE, {})
    if not os.path.exists(CLASSES_FILE):
        save_json_data(CLASSES_FILE, {})
    if not os.path.exists(REPORT_CARDS_FILE):
        save_json_data(REPORT_CARDS_FILE, {})
    if not os.path.exists(SETTINGS_FILE):
        save_json_data(SETTINGS_FILE, {
            'school_name': 'مدرسه قرآن استاد علی محرابی',
            'school_description': 'مرکز تخصصی آموزش قرآن کریم',
            'contact_phone': '09123456789',
            'contact_email': 'info@quran-school.ir'
        })
    
    app.run(debug=True, host='0.0.0.0', port=5000)