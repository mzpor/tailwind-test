//🎯 ماژول ثبت‌نام هوشمند - نسخه 2.0.0
// مکانیزم ثبت‌نام کامل با مسیر نهایی هوشمند

const fs = require('fs');
const path = require('path');
const { sendMessage, sendMessageWithInlineKeyboard } = require('./4bale');

class SmartRegistration {
    constructor() {
        this.dataFile = path.join(__dirname, 'data', 'smart_registration.json');
        this.userStates = {};
        this.loadData();
    }

    // بارگذاری داده‌ها از فایل JSON
    loadData() {
        try {
            if (fs.existsSync(this.dataFile)) {
                const data = fs.readFileSync(this.dataFile, 'utf8');
                const parsed = JSON.parse(data);
                this.userData = parsed.userData || {};
                this.userStates = parsed.userStates || {};
                this.lastUpdated = parsed.lastUpdated;
            } else {
                this.userData = {};
                this.userStates = {};
                this.lastUpdated = new Date().toISOString();
            }
        } catch (error) {
            console.error('خطا در بارگذاری داده‌ها:', error);
            this.userData = {};
            this.userStates = {};
            this.lastUpdated = new Date().toISOString();
        }
    }

    // ذخیره داده‌ها در فایل JSON
    saveData() {
        try {
            const data = {
                userData: this.userData,
                userStates: this.userStates,
                lastUpdated: new Date().toISOString()
            };
            fs.writeFileSync(this.dataFile, JSON.stringify(data, null, 2), 'utf8');
        } catch (error) {
            console.error('خطا در ذخیره داده‌ها:', error);
        }
    }

    // شروع ثبت نام
    startRegistration(userId) {
        this.userStates[userId] = {
            step: 'welcome',
            data: {},
            timestamp: Date.now()
        };
        this.saveData();
        
        return {
            text: `🎓 *به مدرسه قرآن خوش آمدید!*\n\n` +
                  `سلام! من ربات ثبت نام مدرسه قرآن هستم. ` +
                  `بیایید با هم مراحل ثبت نام را طی کنیم.\n\n` +
                  `برای شروع، لطفاً نام و نام خانوادگی خود را وارد کنید:`,
            keyboard: {
                inline_keyboard: [
                    [{ text: '❌ انصراف', callback_data: 'cancel_registration' }]
                ]
            }
        };
    }

    // پردازش ورودی کاربر
    processInput(userId, text) {
        const state = this.userStates[userId];
        if (!state) {
            return this.startRegistration(userId);
        }

        switch (state.step) {
            case 'welcome':
                return this.processFullName(userId, text);
            case 'first_name':
                return this.processFirstName(userId, text);
            case 'national_id':
                return this.processNationalId(userId, text);
            case 'phone':
                return this.processPhone(userId, text);
            case 'verification':
                return this.processVerification(userId, text);
            default:
                return this.startRegistration(userId);
        }
    }

    // پردازش نام کامل
    processFullName(userId, text) {
        const names = text.trim().split(' ');
        if (names.length < 2) {
            return {
                text: `❌ لطفاً نام و نام خانوادگی را کامل وارد کنید.\n` +
                      `مثال: احمد محمدی`,
                keyboard: {
                    inline_keyboard: [
                        [{ text: '❌ انصراف', callback_data: 'cancel_registration' }]
                    ]
                }
            };
        }

        this.userStates[userId].data.full_name = text.trim();
        this.userStates[userId].step = 'first_name';
        this.saveData();

        return {
            text: `✅ نام کامل ثبت شد: *${text.trim()}*\n\n` +
                  `حالا لطفاً نام کوچک خود را وارد کنید (برای خوشامدگویی):`,
            keyboard: {
                inline_keyboard: [
                    [{ text: '❌ انصراف', callback_data: 'cancel_registration' }]
                ]
            }
        };
    }

    // پردازش نام کوچک
    processFirstName(userId, text) {
        const firstName = text.trim();
        if (firstName.length < 2) {
            return {
                text: `❌ لطفاً نام کوچک را کامل وارد کنید.`,
                keyboard: {
                    inline_keyboard: [
                        [{ text: '❌ انصراف', callback_data: 'cancel_registration' }]
                    ]
                }
            };
        }

        this.userStates[userId].data.first_name = firstName;
        this.userStates[userId].step = 'national_id';
        this.saveData();

        return {
            text: `✅ نام کوچک ثبت شد: *${firstName}*\n\n` +
                  `حالا لطفاً کد ملی خود را وارد کنید:`,
            keyboard: {
                inline_keyboard: [
                    [{ text: '❌ انصراف', callback_data: 'cancel_registration' }]
                ]
            }
        };
    }

    // پردازش کد ملی
    processNationalId(userId, text) {
        const nationalId = text.trim();
        if (!/^\d{10}$/.test(nationalId)) {
            return {
                text: `❌ کد ملی باید 10 رقم باشد.\n` +
                      `لطفاً کد ملی صحیح را وارد کنید:`,
                keyboard: {
                    inline_keyboard: [
                        [{ text: '❌ انصراف', callback_data: 'cancel_registration' }]
                    ]
                }
            };
        }

        this.userStates[userId].data.national_id = nationalId;
        this.userStates[userId].step = 'phone';
        this.saveData();

        return {
            text: `✅ کد ملی ثبت شد: *${nationalId}*\n\n` +
                  `حالا لطفاً شماره تلفن خود را وارد کنید:\n` +
                  `مثال: 09123456789`,
            keyboard: {
                inline_keyboard: [
                    [{ text: '❌ انصراف', callback_data: 'cancel_registration' }]
                ]
            }
        };
    }

    // پردازش شماره تلفن
    processPhone(userId, text) {
        const phone = text.trim().replace(/^0/, '98');
        if (!/^98\d{10}$/.test(phone)) {
            return {
                text: `❌ شماره تلفن صحیح نیست.\n` +
                      `لطفاً شماره تلفن معتبر وارد کنید:\n` +
                      `مثال: 09123456789`,
                keyboard: {
                    inline_keyboard: [
                        [{ text: '❌ انصراف', callback_data: 'cancel_registration' }]
                    ]
                }
            };
        }

        this.userStates[userId].data.phone = phone;
        this.userStates[userId].step = 'verification';
        this.saveData();

        return {
            text: `✅ شماره تلفن ثبت شد: *${phone}*\n\n` +
                  `📱 کد تایید برای شما ارسال شد.\n` +
                  `لطفاً کد 6 رقمی را وارد کنید:`,
            keyboard: {
                inline_keyboard: [
                    [{ text: '🔄 ارسال مجدد کد', callback_data: 'resend_code' }],
                    [{ text: '❌ انصراف', callback_data: 'cancel_registration' }]
                ]
            }
        };
    }

    // پردازش تایید
    processVerification(userId, text) {
        const code = text.trim();
        if (!/^\d{6}$/.test(code)) {
            return {
                text: `❌ کد تایید باید 6 رقم باشد.\n` +
                      `لطفاً کد صحیح را وارد کنید:`,
                keyboard: {
                    inline_keyboard: [
                        [{ text: '🔄 ارسال مجدد کد', callback_data: 'resend_code' }],
                        [{ text: '❌ انصراف', callback_data: 'cancel_registration' }]
                    ]
                }
            };
        }

        // در اینجا باید کد تایید بررسی شود
        // فعلاً فرض می‌کنیم کد صحیح است
        return this.completeRegistration(userId);
    }

    // تکمیل ثبت نام
    completeRegistration(userId) {
        const state = this.userStates[userId];
        const userData = {
            full_name: state.data.full_name,
            first_name: state.data.first_name,
            national_id: state.data.national_id,
            phone: state.data.phone,
            user_type: 'quran_student',
            registration_date: Date.now()
        };

        this.userData[userId] = userData;
        delete this.userStates[userId];
        this.saveData();

        return {
            text: `🎉 *ثبت نام با موفقیت تکمیل شد!*\n\n` +
                  `👤 نام: *${userData.full_name}*\n` +
                  `📱 تلفن: *${userData.phone}*\n` +
                  `🆔 کد ملی: *${userData.national_id}*\n\n` +
                  `حالا می‌توانید کارگاه مورد نظر خود را انتخاب کنید:`,
            keyboard: {
                inline_keyboard: [
                    [{ text: '🏫 انتخاب کارگاه', callback_data: 'select_workshop' }],
                    [{ text: '📊 پروفایل من', callback_data: 'my_profile' }],
                    [{ text: '❌ خروج', callback_data: 'exit' }]
                ]
            }
        };
    }

    // بررسی وضعیت کاربر
    checkUserStatus(userId) {
        const user = this.userData[userId];
        if (!user) {
            return { exists: false, complete: false };
        }

        const requiredFields = ['full_name', 'first_name', 'national_id', 'phone'];
        const complete = requiredFields.every(field => user[field]);

        return { exists: true, complete };
    }

    // درخواست تکمیل حساب
    requestProfileCompletion(userId) {
        const user = this.userData[userId];
        const missingFields = [];
        
        if (!user.full_name) missingFields.push('نام و نام خانوادگی');
        if (!user.first_name) missingFields.push('نام کوچک');
        if (!user.national_id) missingFields.push('کد ملی');
        if (!user.phone) missingFields.push('شماره تلفن');

        return {
            text: `⚠️ *حساب کاربری شما ناقص است!*\n\n` +
                  `لطفاً موارد زیر را تکمیل کنید:\n` +
                  `${missingFields.map(field => `• ${field}`).join('\n')}\n\n` +
                  `برای تکمیل حساب کلیک کنید:`,
            keyboard: {
                inline_keyboard: [
                    [{ text: '🔧 تکمیل حساب', callback_data: 'complete_profile' }],
                    [{ text: '❌ انصراف', callback_data: 'cancel' }]
                ]
            }
        };
    }

    // پردازش callback ها
    processCallback(userId, callbackData) {
        switch (callbackData) {
            case 'cancel_registration':
                delete this.userStates[userId];
                this.saveData();
                return {
                    text: `❌ ثبت نام لغو شد.\n\n` +
                          `برای شروع مجدد، دستور /start را ارسال کنید.`,
                    keyboard: {
                        inline_keyboard: [
                            [{ text: '🔄 شروع مجدد', callback_data: 'restart' }]
                        ]
                    }
                };

            case 'resend_code':
                return {
                    text: `📱 کد تایید جدید ارسال شد.\n\n` +
                          `لطفاً کد 6 رقمی را وارد کنید:`,
                    keyboard: {
                        inline_keyboard: [
                            [{ text: '🔄 ارسال مجدد کد', callback_data: 'resend_code' }],
                            [{ text: '❌ انصراف', callback_data: 'cancel_registration' }]
                        ]
                    }
                };

            case 'select_workshop':
                return {
                    text: `🏫 *انتخاب کارگاه*\n\n` +
                          `لطفاً کارگاه مورد نظر خود را انتخاب کنید:`,
                    keyboard: {
                        inline_keyboard: [
                            [{ text: '📖 حفظ قرآن', callback_data: 'workshop_hifz' }],
                            [{ text: '📚 تفسیر قرآن', callback_data: 'workshop_tafsir' }],
                            [{ text: '🎵 تجوید', callback_data: 'workshop_tajweed' }],
                            [{ text: '🔙 بازگشت', callback_data: 'back_to_main' }]
                        ]
                    }
                };

            case 'my_profile':
                const user = this.userData[userId];
                return {
                    text: `👤 *پروفایل کاربری*\n\n` +
                          `📝 نام: *${user.full_name}*\n` +
                          `📱 تلفن: *${user.phone}*\n` +
                          `🆔 کد ملی: *${user.national_id}*\n` +
                          `📅 تاریخ ثبت نام: *${new Date(user.registration_date).toLocaleDateString('fa-IR')}*`,
                    keyboard: {
                        inline_keyboard: [
                            [{ text: '✏️ ویرایش پروفایل', callback_data: 'edit_profile' }],
                            [{ text: '🔙 بازگشت', callback_data: 'back_to_main' }]
                        ]
                    }
                };

            case 'restart':
                return this.startRegistration(userId);

            default:
                return {
                    text: `❓ دستور نامعتبر است.\n\n` +
                          `لطفاً از منوی اصلی انتخاب کنید:`,
                    keyboard: {
                        inline_keyboard: [
                            [{ text: '🔄 شروع مجدد', callback_data: 'restart' }],
                            [{ text: '❌ خروج', callback_data: 'exit' }]
                        ]
                    }
                };
        }
    }

    // دریافت منوی اصلی
    getMainMenu(userId) {
        const userStatus = this.checkUserStatus(userId);
        
        if (!userStatus.exists) {
            return this.startRegistration(userId);
        }

        if (!userStatus.complete) {
            return this.requestProfileCompletion(userId);
        }

        const user = this.userData[userId];
        return {
            text: `🎓 *خوش آمدید ${user.first_name} عزیز!*\n\n` +
                  `به منوی اصلی مدرسه قرآن خوش آمدید.\n` +
                  `چه کاری می‌توانم برایتان انجام دهم؟`,
            keyboard: {
                inline_keyboard: [
                    [{ text: '🏫 انتخاب کارگاه', callback_data: 'select_workshop' }],
                    [{ text: '👤 پروفایل من', callback_data: 'my_profile' }],
                    [{ text: '📊 وضعیت ثبت نام', callback_data: 'registration_status' }],
                    [{ text: '❌ خروج', callback_data: 'exit' }]
                ]
            }
        };
    }
}

module.exports = SmartRegistration;
